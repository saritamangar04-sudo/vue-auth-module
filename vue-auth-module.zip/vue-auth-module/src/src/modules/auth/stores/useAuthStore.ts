import { defineStore } from "pinia";
import { ref, computed } from "vue";
import type { User, LoginCredentials, RegisterCredentials } from "../types";

export const useAuthStore = defineStore("auth", () => {
  const user = ref<User | null>(
    JSON.parse(localStorage.getItem("auth_user") || "null"),
  );
  const token = ref<string | null>(localStorage.getItem("auth_token") || null);
  const isLoading = ref<boolean>(false);
  const error = ref<string | null>(null);

  const isAuthenticated = computed(() => Boolean(token.value && user.value));

  async function login(credentials: LoginCredentials): Promise<boolean> {
    isLoading.value = true;
    error.value = null;
    try {
      await new Promise((resolve) => setTimeout(resolve, 800));

      if (
        credentials.email === "admin@fleet.com" &&
        credentials.password === "Password123!"
      ) {
        const mockUser: User = {
          id: "usr_101",
          name: "Sarita Mangar",
          email: credentials.email,
        };
        const mockToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.mock_token";

        setSession(mockUser, mockToken);
        return true;
      } else {
        throw new Error("Invalid email or password credentials.");
      }
    } catch (err: unknown) {
      error.value =
        err instanceof Error
          ? err.message
          : "An unknown authentication error occurred.";
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  async function register(credentials: RegisterCredentials): Promise<boolean> {
    isLoading.value = true;
    error.value = null;
    try {
      await new Promise((resolve) => setTimeout(resolve, 800));

      const mockUser: User = {
        id: `usr_${Date.now()}`,
        name: credentials.name,
        email: credentials.email,
      };
      const mockToken = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.registered_${Date.now()}`;

      setSession(mockUser, mockToken);
      return true;
    } catch (err: unknown) {
      error.value = err instanceof Error ? err.message : "Registration failed.";
      return false;
    } finally {
      isLoading.value = false;
    }
  }

  function logout(): void {
    user.value = null;
    token.value = null;
    error.value = null;
    localStorage.removeItem("auth_token");
    localStorage.removeItem("auth_user");
  }

  function setSession(userData: User, tokenData: string): void {
    user.value = userData;
    token.value = tokenData;
    localStorage.setItem("auth_user", JSON.stringify(userData));
    localStorage.setItem("auth_token", tokenData);
  }

  return {
    user,
    token,
    isLoading,
    error,
    isAuthenticated,
    login,
    register,
    logout,
  };
});
