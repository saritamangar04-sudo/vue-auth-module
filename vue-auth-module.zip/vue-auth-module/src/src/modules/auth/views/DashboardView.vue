<template>
  <div class="min-h-screen bg-gray-900 text-white">
    <nav
      class="bg-gray-800 border-b border-gray-700 px-6 py-4 flex justify-between items-center"
    >
      <h1 class="text-xl font-bold tracking-wide">Enterprise Auth Portal</h1>
      <div class="flex items-center space-x-4">
        <span class="text-sm text-gray-300"
          >Logged in as: <strong>{{ authStore.user?.name }}</strong></span
        >
        <button
          @click="handleLogout"
          class="px-4 py-2 bg-red-600 hover:bg-red-700 text-sm font-semibold rounded-lg transition"
        >
          Sign Out
        </button>
      </div>
    </nav>

    <main
      class="max-w-4xl mx-auto mt-10 p-6 bg-gray-800 rounded-xl border border-gray-700 shadow-xl"
    >
      <h2 class="text-2xl font-bold mb-4">User Session Summary</h2>
      <div
        class="bg-gray-900 p-4 rounded-lg space-y-2 font-mono text-sm border border-gray-700"
      >
        <p>
          <span class="text-blue-400">User ID:</span> {{ authStore.user?.id }}
        </p>
        <p>
          <span class="text-blue-400">Email:</span> {{ authStore.user?.email }}
        </p>
        <p>
          <span class="text-blue-400">JWT Bearer Token:</span>
          {{ authStore.token }}
        </p>
        <p>
          <span class="text-blue-400">Session Status:</span> Active (Persisted
          in LocalStorage)
        </p>
      </div>
    </main>
  </div>
</template>

<script setup lang="ts">
import { useRouter } from "vue-router";
import { useAuthStore } from "../stores/useAuthStore";

const authStore = useAuthStore();
const router = useRouter();

function handleLogout() {
  authStore.logout();
  router.push("/login");
}
</script>
