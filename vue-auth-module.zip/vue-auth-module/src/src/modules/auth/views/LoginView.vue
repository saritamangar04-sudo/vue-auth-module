<template>
  <div
    class="min-h-screen flex items-center justify-center bg-gray-900 text-white px-4"
  >
    <div
      class="max-w-md w-full bg-gray-800 p-8 rounded-xl shadow-2xl border border-gray-700"
    >
      <h2 class="text-3xl font-bold text-center mb-2">Welcome Back</h2>
      <p class="text-gray-400 text-sm text-center mb-6">
        Enter your credentials to access your session.
      </p>

      <div
        v-if="authStore.error"
        class="mb-4 p-3 bg-red-900/50 border border-red-500 text-red-200 rounded text-sm"
      >
        {{ authStore.error }}
      </div>

      <form @submit.prevent="handleLogin" class="space-y-4" novalidate>
        <div>
          <label class="block text-sm font-medium mb-1">Email Address</label>
          <input
            v-model="form.email"
            type="email"
            class="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            :class="{ 'border-red-500': errors.email }"
          />
          <span v-if="errors.email" class="text-xs text-red-400 mt-1 block">{{
            errors.email
          }}</span>
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Password</label>
          <input
            v-model="form.password"
            type="password"
            class="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            :class="{ 'border-red-500': errors.password }"
          />
          <span
            v-if="errors.password"
            class="text-xs text-red-400 mt-1 block"
            >{{ errors.password }}</span
          >
        </div>

        <button
          type="submit"
          :disabled="authStore.isLoading"
          class="w-full py-3 bg-blue-600 hover:bg-blue-700 font-semibold rounded-lg transition duration-200 disabled:opacity-50"
        >
          <span v-if="authStore.isLoading">Authenticating...</span>
          <span v-else>Sign In</span>
        </button>
      </form>

      <p class="mt-6 text-center text-sm text-gray-400">
        Don't have an account?
        <router-link to="/register" class="text-blue-400 hover:underline"
          >Register here</router-link
        >
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive } from "vue";
import { useRouter, useRoute } from "vue-router";
import { useAuthStore } from "../stores/useAuthStore";

const authStore = useAuthStore();
const router = useRouter();
const route = useRoute();

const form = reactive({ email: "", password: "" });
const errors = reactive({ email: "", password: "" });

function validateForm(): boolean {
  let isValid = true;
  errors.email = "";
  errors.password = "";

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!form.email) {
    errors.email = "Email is required.";
    isValid = false;
  } else if (!emailPattern.test(form.email)) {
    errors.email = "Please enter a valid email address.";
    isValid = false;
  }

  if (!form.password) {
    errors.password = "Password is required.";
    isValid = false;
  } else if (form.password.length < 6) {
    errors.password = "Password must be at least 6 characters.";
    isValid = false;
  }

  return isValid;
}

async function handleLogin() {
  if (!validateForm()) return;
  const success = await authStore.login({
    email: form.email,
    password: form.password,
  });
  if (success) {
    const redirectPath = (route.query.redirect as string) || "/dashboard";
    router.push(redirectPath);
  }
}
</script>
