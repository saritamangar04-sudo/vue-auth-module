<template>
  <div
    class="min-h-screen flex items-center justify-center bg-gray-900 text-white px-4"
  >
    <div
      class="max-w-md w-full bg-gray-800 p-8 rounded-xl shadow-2xl border border-gray-700"
    >
      <h2 class="text-3xl font-bold text-center mb-2">Create Account</h2>
      <p class="text-gray-400 text-sm text-center mb-6">
        Register to initialize your application session.
      </p>

      <form @submit.prevent="handleRegister" class="space-y-4" novalidate>
        <div>
          <label class="block text-sm font-medium mb-1">Full Name</label>
          <input
            v-model="form.name"
            type="text"
            class="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            :class="{ 'border-red-500': errors.name }"
          />
          <span v-if="errors.name" class="text-xs text-red-400 mt-1 block">{{
            errors.name
          }}</span>
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Email Address</label>
          <input
            v-model="form.email"
            type="email"
            class="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            :class="{ 'border-red-500': errors.email }"
          />
          <span v-if="errors.email" class="text-xs text-red-400 mt-1 block">{{
            errors.email
          }}</span>
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Password</label>
          <input
            v-model="form.password"
            type="password"
            class="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            :class="{ 'border-red-500': errors.password }"
          />
          <span
            v-if="errors.password"
            class="text-xs text-red-400 mt-1 block"
            >{{ errors.password }}</span
          >
        </div>

        <div>
          <label class="block text-sm font-medium mb-1">Confirm Password</label>
          <input
            v-model="form.confirmPassword"
            type="password"
            class="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            :class="{ 'border-red-500': errors.confirmPassword }"
          />
          <span
            v-if="errors.confirmPassword"
            class="text-xs text-red-400 mt-1 block"
            >{{ errors.confirmPassword }}</span
          >
        </div>

        <button
          type="submit"
          :disabled="authStore.isLoading"
          class="w-full py-3 bg-green-600 hover:bg-green-700 font-semibold rounded-lg transition duration-200 disabled:opacity-50"
        >
          <span v-if="authStore.isLoading">Creating Account...</span>
          <span v-else>Register</span>
        </button>
      </form>

      <p class="mt-6 text-center text-sm text-gray-400">
        Already registered?
        <router-link to="/login" class="text-blue-400 hover:underline"
          >Log in</router-link
        >
      </p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { reactive } from "vue";
import { useRouter } from "vue-router";
import { useAuthStore } from "../stores/useAuthStore";

const authStore = useAuthStore();
const router = useRouter();

const form = reactive({
  name: "",
  email: "",
  password: "",
  confirmPassword: "",
});
const errors = reactive({
  name: "",
  email: "",
  password: "",
  confirmPassword: "",
});

function validateForm(): boolean {
  let isValid = true;
  Object.keys(errors).forEach(
    (key) => (errors[key as keyof typeof errors] = ""),
  );

  if (!form.name.trim()) {
    errors.name = "Full name is required.";
    isValid = false;
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!form.email) {
    errors.email = "Email is required.";
    isValid = false;
  } else if (!emailPattern.test(form.email)) {
    errors.email = "Enter a valid email.";
    isValid = false;
  }

  if (!form.password) {
    errors.password = "Password is required.";
    isValid = false;
  } else if (form.password.length < 8) {
    errors.password = "Password must be at least 8 characters.";
    isValid = false;
  }

  if (form.password !== form.confirmPassword) {
    errors.confirmPassword = "Passwords do not match.";
    isValid = false;
  }

  return isValid;
}

async function handleRegister() {
  if (!validateForm()) return;
  const success = await authStore.register({ ...form });
  if (success) router.push("/dashboard");
}
</script>
